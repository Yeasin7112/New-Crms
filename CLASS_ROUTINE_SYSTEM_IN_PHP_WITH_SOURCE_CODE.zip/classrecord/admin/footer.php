


 <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">

                        <p class="text-xs-center tm-footer-text"> Copyright &copy; <?php echo date ("y"); echo "Student of  My College";?></p>
                        
   </div>
					
